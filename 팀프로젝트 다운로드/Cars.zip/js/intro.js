window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        location.href = "index.html";
    }, 103000);
});